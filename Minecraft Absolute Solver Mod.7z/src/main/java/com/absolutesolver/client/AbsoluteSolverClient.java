package com.absolutesolver.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import com.absolutesolver.entities.NullEntity;

public class AbsoluteSolverClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// Client-side initialization
	}
}

